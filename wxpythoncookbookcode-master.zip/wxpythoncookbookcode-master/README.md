# wxPython Cookbook Code Examples

The code examples for the book: **wxPython Cookbook**

The book itself can be purchased through [Gumroad](http://gum.co/wxcookbook) or on [Leanpub](https://leanpub.com/wxpythoncookbook/).

[<img src="http://www.blog.pythonlibrary.org/wp-content/uploads/2016/08/wxcookbook_small.png">](https://leanpub.com/wxpythoncookbook/)